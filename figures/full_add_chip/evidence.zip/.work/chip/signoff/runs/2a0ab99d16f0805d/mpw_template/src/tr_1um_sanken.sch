v {xschem version=3.4.8RC file_version=1.3}
G {}
K {}
V {}
S {}
F {}
E {}
T {OSS_Frame} -90 -670 0 0 0.4 0.4 {}
T {Project Selector} 350 -670 0 0 0.4 0.4 {}
T {Project15
ISHIKAI_INV} 180 260 0 0 0.8 0.8 {}
T {Project4 mmOPAMP+mmBIAS} 1500 350 0 0 0.8 0.8 {}
T {Project14 fujii_inverter} 780 210 0 0 0.8 0.8 {}
T {Project13 kawamoto_inverter} 780 650 0 0 0.8 0.8 {}
T {Project12 kamiyama_inverter} 780 920 0 0 0.8 0.8 {}
T {Project7 kamiyama_Driver} 1510 -840 0 0 0.8 0.8 {}
T {Project5 shishido_opamp_v12} 1500 -150 0 0 0.8 0.8 {}
N -60 -610 10 -610 {lab=P1}
N -60 -590 10 -590 {lab=P2}
N -60 -570 10 -570 {lab=P3}
N -60 -550 10 -550 {lab=P4}
N -60 -530 10 -530 {lab=P5}
N -60 -510 10 -510 {lab=P6}
N -60 -490 10 -490 {lab=P7}
N -60 -470 10 -470 {lab=VSS}
N 130 -610 200 -610 {lab=VDD}
N 130 -590 200 -590 {lab=P15}
N 130 -570 200 -570 {lab=P14}
N 130 -550 200 -550 {lab=P13}
N 130 -530 200 -530 {lab=P12}
N 130 -510 200 -510 {lab=P11}
N 130 -490 200 -490 {lab=P10}
N 130 -470 200 -470 {lab=P9}
N 720 -610 720 -600 {lab=VDD}
N 630 -610 630 -600 {lab=VDD}
N 540 -610 540 -600 {lab=VDD}
N 450 -610 450 -600 {lab=VDD}
N 470 -570 480 -570 {lab=VDD}
N 480 -610 480 -570 {lab=VDD}
N 560 -570 570 -570 {lab=VDD}
N 570 -610 570 -570 {lab=VDD}
N 650 -570 660 -570 {lab=VDD}
N 660 -610 660 -570 {lab=VDD}
N 740 -570 750 -570 {lab=VDD}
N 750 -610 750 -570 {lab=VDD}
N 720 -610 750 -610 {lab=VDD}
N 380 -530 770 -530 {lab=P15}
N 380 -510 770 -510 {lab=P14}
N 380 -490 770 -490 {lab=P13}
N 380 -470 770 -470 {lab=P12}
N 450 -540 450 -530 {lab=P15}
N 540 -540 540 -510 {lab=P14}
N 630 -540 630 -490 {lab=P13}
N 720 -540 720 -470 {lab=P12}
N 380 -610 720 -610 {lab=VDD}
N 40 -320 80 -320 {lab=SEL3N}
N 200 -320 240 -320 {lab=SEL3P}
N -80 -370 130 -370 {lab=VDD}
N 130 -370 130 -360 {lab=VDD}
N -30 -370 -30 -360 {lab=VDD}
N -80 -270 130 -270 {lab=VSS}
N 130 -280 130 -270 {lab=VSS}
N -30 -280 -30 -270 {lab=VSS}
N 40 -190 80 -190 {lab=SEL2N}
N 200 -190 240 -190 {lab=SEL2P}
N -80 -240 130 -240 {lab=VDD}
N 130 -240 130 -230 {lab=VDD}
N -30 -240 -30 -230 {lab=VDD}
N -80 -140 130 -140 {lab=VSS}
N 130 -150 130 -140 {lab=VSS}
N -30 -150 -30 -140 {lab=VSS}
N 40 -60 80 -60 {lab=SEL1N}
N 200 -60 240 -60 {lab=SEL1P}
N -80 -110 130 -110 {lab=VDD}
N 130 -110 130 -100 {lab=VDD}
N -30 -110 -30 -100 {lab=VDD}
N -80 -10 130 -10 {lab=VSS}
N 130 -20 130 -10 {lab=VSS}
N -30 -20 -30 -10 {lab=VSS}
N 40 70 80 70 {lab=SEL0N}
N 200 70 240 70 {lab=SEL0P}
N -80 20 130 20 {lab=VDD}
N 130 20 130 30 {lab=VDD}
N -30 20 -30 30 {lab=VDD}
N -80 120 130 120 {lab=VSS}
N 130 110 130 120 {lab=VSS}
N -30 110 -30 120 {lab=VSS}
N 510 -360 560 -360 {lab=PJENF}
N 510 -210 560 -210 {lab=PJENE}
N 510 -50 560 -50 {lab=PJEND}
N 510 100 560 100 {lab=PJENC}
N 770 -360 820 -360 {lab=PJENB}
N 770 -210 820 -210 {lab=PJENA}
N 770 -50 820 -50 {lab=PJEN9}
N 770 100 820 100 {lab=PJEN8}
N 1290 -360 1340 -360 {lab=PJEN3}
N 1290 -210 1340 -210 {lab=PJEN2}
N 1290 -50 1340 -50 {lab=PJEN1}
N 1290 100 1340 100 {lab=PJEN0}
N 520 530 550 530 {lab=#net1}
N 500 360 550 360 {lab=#net2}
N 520 870 550 870 {lab=#net3}
N 500 1040 550 1040 {lab=#net4}
N 560 430 620 430 {lab=PJENF}
N 560 430 560 1110 {lab=PJENF}
N 560 1110 620 1110 {lab=PJENF}
N 560 1110 560 1150 {lab=PJENF}
N 560 600 620 600 {lab=PJENF}
N 560 770 620 770 {lab=PJENF}
N 560 940 620 940 {lab=PJENF}
N 460 620 500 620 {lab=#net2}
N 500 360 500 620 {lab=#net2}
N 460 660 520 660 {lab=#net1}
N 520 530 520 660 {lab=#net1}
N 460 700 550 700 {lab=#net5}
N 460 740 520 740 {lab=#net3}
N 520 740 520 870 {lab=#net3}
N 460 780 500 780 {lab=#net4}
N 500 780 500 1040 {lab=#net4}
N 70 700 160 700 {lab=#net6}
N 100 660 160 660 {lab=#net7}
N 100 530 100 660 {lab=#net7}
N 100 740 160 740 {lab=#net8}
N 100 740 100 870 {lab=#net8}
N 70 870 100 870 {lab=#net8}
N 70 530 100 530 {lab=#net7}
N 120 360 120 620 {lab=#net9}
N 70 360 120 360 {lab=#net9}
N 120 620 160 620 {lab=#net9}
N 120 780 120 1040 {lab=#net10}
N 120 780 160 780 {lab=#net10}
N 70 1040 120 1040 {lab=#net10}
N -60 430 0 430 {lab=PJENF}
N -60 430 -60 1150 {lab=PJENF}
N -230 1150 -60 1150 {lab=PJENF}
N -60 1110 0 1110 {lab=PJENF}
N -60 940 0 940 {lab=PJENF}
N -60 770 0 770 {lab=PJENF}
N -60 600 0 600 {lab=PJENF}
N -60 1150 560 1150 {lab=PJENF}
N 1030 -360 1080 -360 {lab=PJEN7}
N 1030 -210 1080 -210 {lab=PJEN6}
N 1030 -50 1080 -50 {lab=PJEN5}
N 1030 100 1080 100 {lab=PJEN4}
N 380 -420 1210 -420 {lab=VDD}
N 380 -300 1210 -300 {lab=VSS}
N 380 -270 1210 -270 {lab=VDD}
N 380 -150 1210 -150 {lab=VSS}
N 380 -110 1210 -110 {lab=VDD}
N 380 10 1210 10 {lab=VSS}
N 380 40 1210 40 {lab=VDD}
N 380 160 1210 160 {lab=VSS}
N 1510 600 1570 600 {lab=PJEN4}
N 1510 770 1570 770 {lab=PJEN4}
N 1900 1130 1960 1130 {lab=PJEN4}
N 1900 600 1900 1130 {lab=PJEN4}
N 1900 600 1960 600 {lab=PJEN4}
N 1900 1130 1900 1170 {lab=PJEN4}
N 1490 1170 1900 1170 {lab=PJEN4}
N 1510 600 1510 770 {lab=PJEN4}
N 1510 770 1510 1170 {lab=PJEN4}
N 1640 530 1660 530 {lab=#net11}
N 1660 530 1660 570 {lab=#net11}
N 1660 570 1680 570 {lab=#net11}
N 1640 700 1660 700 {lab=#net12}
N 1660 650 1660 700 {lab=#net12}
N 1660 650 1680 650 {lab=#net12}
N 1870 530 1870 610 {lab=#net13}
N 1870 530 1890 530 {lab=#net13}
N 1900 780 1960 780 {lab=PJEN4}
N 1900 960 1960 960 {lab=PJEN4}
N 2140 1040 2200 1040 {lab=PJEN4}
N 2140 1040 2140 1170 {lab=PJEN4}
N 1900 1170 2140 1170 {lab=PJEN4}
N 2140 690 2140 1040 {lab=PJEN4}
N 2140 690 2200 690 {lab=PJEN4}
N 2140 870 2200 870 {lab=PJEN4}
N 830 420 890 420 {lab=PJENE}
N 830 590 890 590 {lab=PJENE}
N 960 350 980 350 {lab=#net14}
N 1130 420 1190 420 {lab=PJENE}
N 1100 350 1100 420 {lab=#net15}
N 1100 350 1120 350 {lab=#net15}
N 1100 430 1100 520 {lab=#net16}
N 1100 520 1120 520 {lab=#net16}
N 830 420 830 630 {lab=PJENE}
N 830 630 1190 630 {lab=PJENE}
N 1190 590 1190 630 {lab=PJENE}
N 1130 420 1130 630 {lab=PJENE}
N 780 630 830 630 {lab=PJENE}
N 960 520 980 520 {lab=#net17}
N 830 860 890 860 {lab=PJEND}
N 1130 860 1190 860 {lab=PJEND}
N 960 790 970 790 {lab=#net18}
N 1110 790 1120 790 {lab=#net19}
N 830 860 830 900 {lab=PJEND}
N 830 900 1130 900 {lab=PJEND}
N 1130 860 1130 900 {lab=PJEND}
N 780 900 830 900 {lab=PJEND}
N 830 1130 890 1130 {lab=PJENC}
N 1130 1130 1190 1130 {lab=PJENC}
N 830 1130 830 1170 {lab=PJENC}
N 830 1170 1130 1170 {lab=PJENC}
N 1130 1130 1130 1170 {lab=PJENC}
N 780 1170 830 1170 {lab=PJENC}
N 960 1060 990 1060 {lab=#net20}
N 1090 1060 1120 1060 {lab=#net21}
N 980 350 980 420 {lab=#net14}
N 980 440 980 520 {lab=#net17}
N 2110 -670 2110 -570 {lab=#net22}
N 2030 -570 2110 -570 {lab=#net22}
N 2030 -550 2110 -550 {lab=#net23}
N 2110 -550 2110 -500 {lab=#net23}
N 2030 -530 2090 -530 {lab=#net24}
N 2090 -530 2090 -330 {lab=#net24}
N 2090 -330 2110 -330 {lab=#net24}
N 2030 -470 2070 -470 {lab=#net25}
N 2070 -590 2070 -470 {lab=#net25}
N 2310 -670 2310 -590 {lab=#net25}
N 2030 -450 2070 -450 {lab=#net26}
N 2070 -450 2070 -420 {lab=#net26}
N 2310 -500 2310 -420 {lab=#net26}
N 2030 -430 2050 -430 {lab=#net27}
N 2050 -430 2050 -250 {lab=#net27}
N 2310 -330 2310 -250 {lab=#net27}
N 1640 -670 1640 -570 {lab=#net28}
N 1640 -570 1730 -570 {lab=#net28}
N 1640 -550 1640 -500 {lab=#net29}
N 1640 -550 1730 -550 {lab=#net29}
N 1660 -530 1730 -530 {lab=#net30}
N 1660 -530 1660 -330 {lab=#net30}
N 1640 -330 1660 -330 {lab=#net30}
N 2070 -590 2310 -590 {lab=#net25}
N 2070 -420 2310 -420 {lab=#net26}
N 2050 -250 2310 -250 {lab=#net27}
N 1510 -600 1570 -600 {lab=PJEN7}
N 1510 -260 1570 -260 {lab=PJEN7}
N 1510 -600 1510 -220 {lab=PJEN7}
N 1450 -220 1510 -220 {lab=PJEN7}
N 1510 -430 1570 -430 {lab=PJEN7}
N 2120 -600 2180 -600 {lab=PJEN7}
N 2120 -600 2120 -220 {lab=PJEN7}
N 1510 -220 2120 -220 {lab=PJEN7}
N 2120 -430 2180 -430 {lab=PJEN7}
N 2120 -260 2180 -260 {lab=PJEN7}
N 2320 -600 2380 -600 {lab=PJEN7}
N 2320 -600 2320 -220 {lab=PJEN7}
N 2120 -220 2320 -220 {lab=PJEN7}
N 2320 -260 2380 -260 {lab=PJEN7}
N 2320 -430 2380 -430 {lab=PJEN7}
N 1640 70 1740 70 {lab=#net31}
N 1640 20 1640 70 {lab=#net31}
N 1640 130 1740 130 {lab=#net32}
N 1640 130 1640 190 {lab=#net32}
N 1920 100 2030 100 {lab=#net33}
N 1510 90 1570 90 {lab=PJEN5}
N 1510 90 1510 260 {lab=PJEN5}
N 1510 260 1570 260 {lab=PJEN5}
N 1460 300 1510 300 {lab=PJEN5}
N 1510 260 1510 300 {lab=PJEN5}
N 2040 170 2100 170 {lab=PJEN5}
N 2040 170 2040 300 {lab=PJEN5}
N 1510 300 2040 300 {lab=PJEN5}
C {devices/title.sym} -10 -770 0 0 {name=l1 author="Sanken Electric"}
C {devices/iopin.sym} -60 -610 0 1 {name=p1 lab=P1}
C {devices/iopin.sym} -60 -590 0 1 {name=p2 lab=P2}
C {devices/iopin.sym} -60 -570 0 1 {name=p3 lab=P3}
C {devices/iopin.sym} -60 -550 0 1 {name=p4 lab=P4
}
C {devices/iopin.sym} -60 -530 0 1 {name=p5 lab=P5}
C {devices/iopin.sym} -60 -510 0 1 {name=p6 lab=P6}
C {devices/iopin.sym} -60 -490 0 1 {name=p7 lab=P7}
C {devices/iopin.sym} -60 -470 0 1 {name=p8 lab=VSS}
C {devices/iopin.sym} 200 -610 0 0 {name=p9 lab=VDD}
C {devices/iopin.sym} 200 -590 0 0 {name=p10 lab=P15}
C {devices/iopin.sym} 200 -570 0 0 {name=p11 lab=P14}
C {devices/iopin.sym} 200 -550 0 0 {name=p12 lab=P13
}
C {devices/iopin.sym} 200 -530 0 0 {name=p13 lab=P12}
C {devices/iopin.sym} 200 -510 0 0 {name=p14 lab=P11}
C {devices/iopin.sym} 200 -490 0 0 {name=p15 lab=P10}
C {devices/iopin.sym} 200 -470 0 0 {name=p16 lab=P9}
C {devices/lab_wire.sym} -20 -610 0 0 {name=p17 sig_type=std_logic lab=P1}
C {devices/lab_wire.sym} -20 -590 0 0 {name=p18 sig_type=std_logic lab=P2}
C {devices/lab_wire.sym} -20 -570 0 0 {name=p19 sig_type=std_logic lab=P3}
C {devices/lab_wire.sym} -20 -550 0 0 {name=p20 sig_type=std_logic lab=P4}
C {devices/lab_wire.sym} -20 -530 0 0 {name=p21 sig_type=std_logic lab=P5}
C {devices/lab_wire.sym} -20 -510 0 0 {name=p22 sig_type=std_logic lab=P6}
C {devices/lab_wire.sym} -20 -490 0 0 {name=p23 sig_type=std_logic lab=P7}
C {devices/lab_wire.sym} -20 -470 0 0 {name=p24 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 170 -610 0 0 {name=p25 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 170 -590 0 0 {name=p26 sig_type=std_logic lab=P15}
C {devices/lab_wire.sym} 170 -570 0 0 {name=p27 sig_type=std_logic lab=P14}
C {devices/lab_wire.sym} 170 -550 0 0 {name=p28 sig_type=std_logic lab=P13}
C {devices/lab_wire.sym} 170 -530 0 0 {name=p29 sig_type=std_logic lab=P12}
C {devices/lab_wire.sym} 170 -510 0 0 {name=p30 sig_type=std_logic lab=P11}
C {devices/lab_wire.sym} 170 -490 0 0 {name=p31 sig_type=std_logic lab=P10}
C {devices/lab_wire.sym} 170 -470 0 0 {name=p32 sig_type=std_logic lab=P9}
C {devices/lab_wire.sym} 380 -530 0 0 {name=p33 sig_type=std_logic lab=P15}
C {TR-1umLIB/RR.sym} 450 -600 0 0 {name=R1
w=2.8e-06
R=1
l=100e-06
model=F_RR
spiceprefix=X
tc1=0
tc2=0
m=1}
C {devices/lab_wire.sym} 380 -610 0 0 {name=p34 sig_type=std_logic lab=VDD}
C {TR-1umLIB/RR.sym} 540 -600 0 0 {name=R2
w=2.8e-06
R=1
l=100e-06
model=F_RR
spiceprefix=X
tc1=0
tc2=0
m=1}
C {TR-1umLIB/RR.sym} 630 -600 0 0 {name=R3
w=2.8e-06
R=1
l=100e-06
model=F_RR
spiceprefix=X
tc1=0
tc2=0
m=1}
C {TR-1umLIB/RR.sym} 720 -600 0 0 {name=R4
w=2.8e-06
R=1
l=100e-06
model=F_RR
spiceprefix=X
tc1=0
tc2=0
m=1}
C {devices/lab_wire.sym} 380 -510 0 0 {name=p35 sig_type=std_logic lab=P14}
C {devices/lab_wire.sym} 380 -490 0 0 {name=p36 sig_type=std_logic lab=P13}
C {devices/lab_wire.sym} 380 -470 0 0 {name=p37 sig_type=std_logic lab=P12}
C {TR-1um_5_stdcell/INV_X1.sym} -60 -320 0 0 {name=x2}
C {devices/lab_wire.sym} -80 -320 0 0 {name=p38 sig_type=std_logic lab=P15}
C {TR-1um_5_stdcell/INV_X1.sym} 100 -320 0 0 {name=x3}
C {devices/lab_wire.sym} 380 -420 0 0 {name=p39 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} -80 -270 0 0 {name=p40 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 80 -320 0 0 {name=p41 sig_type=std_logic lab=SEL3N}
C {devices/lab_wire.sym} 240 -320 0 0 {name=p42 sig_type=std_logic lab=SEL3P}
C {TR-1um_5_stdcell/INV_X1.sym} -60 -190 0 0 {name=x4}
C {devices/lab_wire.sym} -80 -190 0 0 {name=p43 sig_type=std_logic lab=P14}
C {TR-1um_5_stdcell/INV_X1.sym} 100 -190 0 0 {name=x5}
C {devices/lab_wire.sym} -80 -240 0 0 {name=p44 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} -80 -140 0 0 {name=p45 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 80 -190 0 0 {name=p46 sig_type=std_logic lab=SEL2N}
C {devices/lab_wire.sym} 240 -190 0 0 {name=p47 sig_type=std_logic lab=SEL2P}
C {TR-1um_5_stdcell/INV_X1.sym} -60 -60 0 0 {name=x6}
C {devices/lab_wire.sym} -80 -60 0 0 {name=p48 sig_type=std_logic lab=P13}
C {TR-1um_5_stdcell/INV_X1.sym} 100 -60 0 0 {name=x7}
C {devices/lab_wire.sym} -80 -110 0 0 {name=p49 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} -80 -10 0 0 {name=p50 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 80 -60 0 0 {name=p51 sig_type=std_logic lab=SEL1N}
C {devices/lab_wire.sym} 240 -60 0 0 {name=p52 sig_type=std_logic lab=SEL1P}
C {TR-1um_5_stdcell/INV_X1.sym} -60 70 0 0 {name=x8}
C {devices/lab_wire.sym} -80 70 0 0 {name=p53 sig_type=std_logic lab=P12}
C {TR-1um_5_stdcell/INV_X1.sym} 100 70 0 0 {name=x9}
C {devices/lab_wire.sym} -80 20 0 0 {name=p54 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} -80 120 0 0 {name=p55 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 80 70 0 0 {name=p56 sig_type=std_logic lab=SEL0N}
C {devices/lab_wire.sym} 240 70 0 0 {name=p57 sig_type=std_logic lab=SEL0P}
C {devices/lab_wire.sym} 380 -300 0 0 {name=p58 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 380 -370 0 0 {name=p59 sig_type=std_logic lab=SEL2P}
C {devices/lab_wire.sym} 380 -390 0 0 {name=p60 sig_type=std_logic lab=SEL3P}
C {devices/lab_wire.sym} 380 -350 0 0 {name=p61 sig_type=std_logic lab=SEL1P}
C {devices/lab_wire.sym} 380 -330 0 0 {name=p62 sig_type=std_logic lab=SEL0P}
C {devices/lab_wire.sym} 560 -360 0 0 {name=p63 sig_type=std_logic lab=PJENF}
C {devices/lab_wire.sym} 380 -270 0 0 {name=p64 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 380 -150 0 0 {name=p65 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 380 -220 0 0 {name=p66 sig_type=std_logic lab=SEL2P}
C {devices/lab_wire.sym} 380 -240 0 0 {name=p67 sig_type=std_logic lab=SEL3P}
C {devices/lab_wire.sym} 380 -200 0 0 {name=p68 sig_type=std_logic lab=SEL1P}
C {devices/lab_wire.sym} 380 -180 0 0 {name=p69 sig_type=std_logic lab=SEL0N}
C {devices/lab_wire.sym} 560 -210 0 0 {name=p70 sig_type=std_logic lab=PJENE}
C {devices/lab_wire.sym} 380 -110 0 0 {name=p71 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 380 10 0 0 {name=p72 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 380 -60 0 0 {name=p73 sig_type=std_logic lab=SEL2P}
C {devices/lab_wire.sym} 380 -80 0 0 {name=p74 sig_type=std_logic lab=SEL3P}
C {devices/lab_wire.sym} 380 -40 0 0 {name=p75 sig_type=std_logic lab=SEL1N}
C {devices/lab_wire.sym} 380 -20 0 0 {name=p76 sig_type=std_logic lab=SEL0P}
C {devices/lab_wire.sym} 560 -50 0 0 {name=p77 sig_type=std_logic lab=PJEND}
C {devices/lab_wire.sym} 380 40 0 0 {name=p78 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 380 160 0 0 {name=p79 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 380 90 0 0 {name=p80 sig_type=std_logic lab=SEL2P}
C {devices/lab_wire.sym} 380 70 0 0 {name=p81 sig_type=std_logic lab=SEL3P}
C {devices/lab_wire.sym} 380 110 0 0 {name=p82 sig_type=std_logic lab=SEL1N}
C {devices/lab_wire.sym} 380 130 0 0 {name=p83 sig_type=std_logic lab=SEL0N}
C {devices/lab_wire.sym} 560 100 0 0 {name=p84 sig_type=std_logic lab=PJENC}
C {devices/lab_wire.sym} 640 -370 0 0 {name=p87 sig_type=std_logic lab=SEL2N}
C {devices/lab_wire.sym} 640 -390 0 0 {name=p88 sig_type=std_logic lab=SEL3P}
C {devices/lab_wire.sym} 640 -350 0 0 {name=p89 sig_type=std_logic lab=SEL1P}
C {devices/lab_wire.sym} 640 -330 0 0 {name=p90 sig_type=std_logic lab=SEL0P}
C {devices/lab_wire.sym} 820 -360 0 0 {name=p91 sig_type=std_logic lab=PJENB}
C {devices/lab_wire.sym} 640 -220 0 0 {name=p94 sig_type=std_logic lab=SEL2N}
C {devices/lab_wire.sym} 640 -240 0 0 {name=p95 sig_type=std_logic lab=SEL3P}
C {devices/lab_wire.sym} 640 -200 0 0 {name=p96 sig_type=std_logic lab=SEL1P}
C {devices/lab_wire.sym} 640 -180 0 0 {name=p97 sig_type=std_logic lab=SEL0N}
C {devices/lab_wire.sym} 820 -210 0 0 {name=p98 sig_type=std_logic lab=PJENA}
C {devices/lab_wire.sym} 640 -60 0 0 {name=p101 sig_type=std_logic lab=SEL2N}
C {devices/lab_wire.sym} 640 -80 0 0 {name=p102 sig_type=std_logic lab=SEL3P}
C {devices/lab_wire.sym} 640 -40 0 0 {name=p103 sig_type=std_logic lab=SEL1N}
C {devices/lab_wire.sym} 640 -20 0 0 {name=p104 sig_type=std_logic lab=SEL0P}
C {devices/lab_wire.sym} 820 -50 0 0 {name=p105 sig_type=std_logic lab=PJEN9}
C {devices/lab_wire.sym} 640 90 0 0 {name=p108 sig_type=std_logic lab=SEL2N}
C {devices/lab_wire.sym} 640 70 0 0 {name=p109 sig_type=std_logic lab=SEL3P}
C {devices/lab_wire.sym} 640 110 0 0 {name=p110 sig_type=std_logic lab=SEL1N}
C {devices/lab_wire.sym} 640 130 0 0 {name=p111 sig_type=std_logic lab=SEL0N}
C {devices/lab_wire.sym} 820 100 0 0 {name=p112 sig_type=std_logic lab=PJEN8}
C {devices/lab_wire.sym} 900 -370 0 0 {name=p115 sig_type=std_logic lab=SEL2P}
C {devices/lab_wire.sym} 900 -390 0 0 {name=p116 sig_type=std_logic lab=SEL3N}
C {devices/lab_wire.sym} 900 -350 0 0 {name=p117 sig_type=std_logic lab=SEL1P}
C {devices/lab_wire.sym} 900 -330 0 0 {name=p118 sig_type=std_logic lab=SEL0P}
C {devices/lab_wire.sym} 900 -220 0 0 {name=p122 sig_type=std_logic lab=SEL2P}
C {devices/lab_wire.sym} 900 -240 0 0 {name=p123 sig_type=std_logic lab=SEL3N}
C {devices/lab_wire.sym} 900 -200 0 0 {name=p124 sig_type=std_logic lab=SEL1P}
C {devices/lab_wire.sym} 900 -180 0 0 {name=p125 sig_type=std_logic lab=SEL0N}
C {devices/lab_wire.sym} 900 -60 0 0 {name=p129 sig_type=std_logic lab=SEL2P}
C {devices/lab_wire.sym} 900 -80 0 0 {name=p130 sig_type=std_logic lab=SEL3N}
C {devices/lab_wire.sym} 900 -40 0 0 {name=p131 sig_type=std_logic lab=SEL1N}
C {devices/lab_wire.sym} 900 -20 0 0 {name=p132 sig_type=std_logic lab=SEL0P}
C {devices/lab_wire.sym} 900 90 0 0 {name=p136 sig_type=std_logic lab=SEL2P}
C {devices/lab_wire.sym} 900 70 0 0 {name=p137 sig_type=std_logic lab=SEL3N}
C {devices/lab_wire.sym} 900 110 0 0 {name=p138 sig_type=std_logic lab=SEL1N}
C {devices/lab_wire.sym} 900 130 0 0 {name=p139 sig_type=std_logic lab=SEL0N}
C {devices/lab_wire.sym} 1340 -360 0 0 {name=p147 sig_type=std_logic lab=PJEN3}
C {devices/lab_wire.sym} 1340 -210 0 0 {name=p154 sig_type=std_logic lab=PJEN2}
C {devices/lab_wire.sym} 1340 -50 0 0 {name=p161 sig_type=std_logic lab=PJEN1}
C {devices/lab_wire.sym} 1340 100 0 0 {name=p168 sig_type=std_logic lab=PJEN0}
C {devices/lab_wire.sym} -80 -370 0 0 {name=p169 sig_type=std_logic lab=VDD}
C {ISHIKAI_INV.sym} 310 700 0 0 {name=x42}
C {devices/lab_wire.sym} -70 360 0 0 {name=p172 sig_type=std_logic lab=P1}
C {devices/lab_wire.sym} 310 570 0 0 {name=p192 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 310 830 0 0 {name=p193 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} -70 530 0 0 {name=p198 sig_type=std_logic lab=P3}
C {devices/lab_wire.sym} -70 700 0 0 {name=p206 sig_type=std_logic lab=P5}
C {devices/lab_wire.sym} -70 870 0 0 {name=p214 sig_type=std_logic lab=P7}
C {devices/lab_wire.sym} -70 1040 0 0 {name=p230 sig_type=std_logic lab=P10}
C {devices/lab_wire.sym} 40 1110 0 1 {name=p232 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} -230 1150 0 0 {name=p236 sig_type=std_logic lab=PJENF}
C {devices/lab_wire.sym} 660 290 0 1 {name=p210 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 660 460 0 1 {name=p211 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 660 630 0 1 {name=p218 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 660 800 0 1 {name=p219 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 660 970 0 1 {name=p226 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 660 430 0 1 {name=p227 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 660 600 0 1 {name=p234 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 660 770 0 1 {name=p237 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 660 940 0 1 {name=p238 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 660 1110 0 1 {name=p239 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 690 360 0 1 {name=p241 sig_type=std_logic lab=P2}
C {devices/lab_wire.sym} 690 530 0 1 {name=p242 sig_type=std_logic lab=P4}
C {devices/lab_wire.sym} 690 700 0 1 {name=p243 sig_type=std_logic lab=P6}
C {devices/lab_wire.sym} 690 870 0 1 {name=p244 sig_type=std_logic lab=P9}
C {devices/lab_wire.sym} 690 1040 0 1 {name=p245 sig_type=std_logic lab=P11}
C {devices/lab_wire.sym} 40 970 0 1 {name=p175 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 40 940 0 1 {name=p170 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 40 770 0 1 {name=p171 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 40 600 0 1 {name=p173 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 40 430 0 1 {name=p174 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 40 800 0 1 {name=p176 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 40 630 0 1 {name=p179 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 40 460 0 1 {name=p180 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 40 290 0 1 {name=p181 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1080 -360 0 0 {name=p85 sig_type=std_logic lab=PJEN7}
C {devices/lab_wire.sym} 1080 -210 0 0 {name=p86 sig_type=std_logic lab=PJEN6}
C {devices/lab_wire.sym} 1080 -50 0 0 {name=p92 sig_type=std_logic lab=PJEN5}
C {devices/lab_wire.sym} 1080 100 0 0 {name=p93 sig_type=std_logic lab=PJEN4}
C {devices/lab_wire.sym} 1160 -370 0 0 {name=p99 sig_type=std_logic lab=SEL2N}
C {devices/lab_wire.sym} 1160 -390 0 0 {name=p100 sig_type=std_logic lab=SEL3N}
C {devices/lab_wire.sym} 1160 -350 0 0 {name=p106 sig_type=std_logic lab=SEL1P}
C {devices/lab_wire.sym} 1160 -330 0 0 {name=p107 sig_type=std_logic lab=SEL0P}
C {devices/lab_wire.sym} 1160 -220 0 0 {name=p113 sig_type=std_logic lab=SEL2N}
C {devices/lab_wire.sym} 1160 -240 0 0 {name=p114 sig_type=std_logic lab=SEL3N}
C {devices/lab_wire.sym} 1160 -200 0 0 {name=p120 sig_type=std_logic lab=SEL1P}
C {devices/lab_wire.sym} 1160 -180 0 0 {name=p121 sig_type=std_logic lab=SEL0N}
C {devices/lab_wire.sym} 1160 -60 0 0 {name=p127 sig_type=std_logic lab=SEL2N}
C {devices/lab_wire.sym} 1160 -80 0 0 {name=p128 sig_type=std_logic lab=SEL3N}
C {devices/lab_wire.sym} 1160 -40 0 0 {name=p134 sig_type=std_logic lab=SEL1N}
C {devices/lab_wire.sym} 1160 -20 0 0 {name=p135 sig_type=std_logic lab=SEL0P}
C {devices/lab_wire.sym} 1160 90 0 0 {name=p141 sig_type=std_logic lab=SEL2N}
C {devices/lab_wire.sym} 1160 70 0 0 {name=p142 sig_type=std_logic lab=SEL3N}
C {devices/lab_wire.sym} 1160 110 0 0 {name=p148 sig_type=std_logic lab=SEL1N}
C {TR-1um_5_stdcell/AND4_X1.sym} 400 -360 0 0 {name=x10}
C {TR-1um_5_stdcell/AND4_X1.sym} 400 -210 0 0 {name=x11}
C {TR-1um_5_stdcell/AND4_X1.sym} 400 -50 0 0 {name=x12}
C {TR-1um_5_stdcell/AND4_X1.sym} 400 100 0 0 {name=x13}
C {TR-1um_5_stdcell/AND4_X1.sym} 660 -360 0 0 {name=x14}
C {TR-1um_5_stdcell/AND4_X1.sym} 660 -210 0 0 {name=x15}
C {TR-1um_5_stdcell/AND4_X1.sym} 660 -50 0 0 {name=x16}
C {TR-1um_5_stdcell/AND4_X1.sym} 660 100 0 0 {name=x17}
C {TR-1um_5_stdcell/AND4_X1.sym} 920 -360 0 0 {name=x18}
C {TR-1um_5_stdcell/AND4_X1.sym} 920 -210 0 0 {name=x19}
C {TR-1um_5_stdcell/AND4_X1.sym} 920 -50 0 0 {name=x20}
C {TR-1um_5_stdcell/AND4_X1.sym} 920 100 0 0 {name=x21}
C {TR-1um_5_stdcell/AND4_X1.sym} 1180 -360 0 0 {name=x22}
C {TR-1um_5_stdcell/AND4_X1.sym} 1180 -210 0 0 {name=x23}
C {TR-1um_5_stdcell/AND4_X1.sym} 1180 -50 0 0 {name=x24}
C {TR-1um_5_stdcell/AND4_X1.sym} 1180 100 0 0 {name=x25}
C {devices/lab_wire.sym} 1160 130 0 0 {name=p119 sig_type=std_logic lab=SEL0N}
C {OSS_FRAME.sym} 70 -540 0 0 {name=x1}
C {devices/lab_wire.sym} 780 630 0 0 {name=p157 sig_type=std_logic lab=PJENE}
C {fujii_inverter.sym} 1040 420 0 0 {name=x28}
C {devices/lab_wire.sym} 1500 530 0 0 {name=p158 sig_type=std_logic lab=P1}
C {devices/lab_wire.sym} 1500 700 0 0 {name=p159 sig_type=std_logic lab=P2}
C {devices/lab_wire.sym} 1610 770 0 1 {name=p163 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1610 600 0 1 {name=p164 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1610 630 0 1 {name=p166 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1610 460 0 1 {name=p167 sig_type=std_logic lab=VDD}
C {mmOPAMP.sym} 1710 610 0 0 {name=x33}
C {mmBIAS.sym} 1650 980 0 0 {name=x34}
C {devices/lab_wire.sym} 1490 1170 0 0 {name=p160 sig_type=std_logic lab=PJEN4}
C {devices/lab_wire.sym} 2030 530 0 1 {name=p162 sig_type=std_logic lab=P3}
C {devices/lab_wire.sym} 1570 1080 0 0 {name=p165 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1570 880 0 0 {name=p177 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1730 880 0 1 {name=p178 sig_type=std_logic lab=mmIB1MP}
C {devices/lab_wire.sym} 1730 920 0 1 {name=p182 sig_type=std_logic lab=mmVB37}
C {devices/lab_wire.sym} 1730 960 0 1 {name=p183 sig_type=std_logic lab=mmVB18}
C {devices/lab_wire.sym} 1730 1000 0 1 {name=p184 sig_type=std_logic lab=mmVB12}
C {devices/lab_wire.sym} 1730 1040 0 1 {name=p185 sig_type=std_logic lab=mmVBG}
C {devices/lab_wire.sym} 1730 1080 0 1 {name=p186 sig_type=std_logic lab=mmIB1MN}
C {devices/lab_wire.sym} 2030 710 0 1 {name=p187 sig_type=std_logic lab=P4}
C {devices/lab_wire.sym} 2030 890 0 1 {name=p188 sig_type=std_logic lab=P5}
C {devices/lab_wire.sym} 2030 1060 0 1 {name=p189 sig_type=std_logic lab=P6}
C {devices/lab_wire.sym} 2270 620 0 1 {name=p190 sig_type=std_logic lab=P7}
C {devices/lab_wire.sym} 2270 800 0 1 {name=p191 sig_type=std_logic lab=P9}
C {devices/lab_wire.sym} 2270 970 0 1 {name=p194 sig_type=std_logic lab=P10}
C {devices/lab_wire.sym} 1890 710 0 0 {name=p195 sig_type=std_logic lab=mmVBG}
C {devices/lab_wire.sym} 1890 890 0 0 {name=p196 sig_type=std_logic lab=mmVB12}
C {devices/lab_wire.sym} 1890 1060 0 0 {name=p197 sig_type=std_logic lab=mmVB18}
C {devices/lab_wire.sym} 2130 620 0 0 {name=p199 sig_type=std_logic lab=mmVB37}
C {devices/lab_wire.sym} 2130 800 0 0 {name=p200 sig_type=std_logic lab=mmIB1MP}
C {devices/lab_wire.sym} 2130 970 0 0 {name=p201 sig_type=std_logic lab=mmIB1MN}
C {devices/lab_wire.sym} 1780 510 3 1 {name=p202 sig_type=std_logic lab=mmVB37}
C {devices/lab_wire.sym} 1760 510 3 1 {name=p203 sig_type=std_logic lab=mmIB1MP}
C {devices/lab_wire.sym} 1800 510 3 1 {name=p204 sig_type=std_logic lab=mmVB18}
C {devices/lab_wire.sym} 1760 710 3 0 {name=p205 sig_type=std_logic lab=mmIB1MN}
C {devices/lab_wire.sym} 1780 710 3 0 {name=p207 sig_type=std_logic lab=mmVB12}
C {devices/lab_wire.sym} 1730 510 0 0 {name=p208 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1730 710 0 0 {name=p209 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2000 600 0 1 {name=p212 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2000 460 0 1 {name=p213 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2000 780 0 1 {name=p215 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2000 640 0 1 {name=p216 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2000 960 0 1 {name=p217 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2000 820 0 1 {name=p220 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2000 1130 0 1 {name=p221 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2000 990 0 1 {name=p224 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2240 1040 0 1 {name=p225 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2240 900 0 1 {name=p223 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2240 870 0 1 {name=p222 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2240 730 0 1 {name=p228 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2240 690 0 1 {name=p229 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2240 550 0 1 {name=p231 sig_type=std_logic lab=VDD}
C {ASWSL.sym} 0 360 0 0 {name=x43}
C {ASWSL.sym} 0 530 0 0 {name=x44}
C {ASWSL.sym} 0 700 0 0 {name=x45}
C {ASWSL.sym} 0 870 0 0 {name=x46}
C {ASWSL.sym} 0 1040 0 0 {name=x47}
C {ASWS.sym} 620 360 0 0 {name=x48}
C {ASWS.sym} 620 530 0 0 {name=x49}
C {ASWS.sym} 620 700 0 0 {name=x50}
C {ASWS.sym} 620 870 0 0 {name=x51}
C {ASWS.sym} 620 1040 0 0 {name=x52}
C {ASWSL.sym} 890 350 0 0 {name=x26}
C {ASWSL.sym} 890 520 0 0 {name=x27}
C {ASWS.sym} 1190 350 0 0 {name=x29}
C {ASWS.sym} 1190 520 0 0 {name=x30}
C {ASWSL.sym} 1570 530 0 0 {name=x31}
C {ASWSL.sym} 1570 700 0 0 {name=x32}
C {ASW.sym} 1960 530 0 0 {name=x35}
C {ASWS.sym} 1960 710 0 0 {name=x36}
C {ASWS.sym} 1960 890 0 0 {name=x37}
C {ASWS.sym} 1960 1060 0 0 {name=x38}
C {ASWS.sym} 2200 620 0 0 {name=x39}
C {ASWS.sym} 2200 800 0 0 {name=x40}
C {ASWS.sym} 2200 970 0 0 {name=x41}
C {devices/lab_wire.sym} 820 350 0 0 {name=p233 sig_type=std_logic lab=P1}
C {devices/lab_wire.sym} 820 520 0 0 {name=p235 sig_type=std_logic lab=P3}
C {devices/lab_wire.sym} 930 590 0 1 {name=p240 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 930 420 0 1 {name=p246 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 930 450 0 1 {name=p247 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 930 280 0 1 {name=p248 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1020 380 0 1 {name=p249 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1020 460 0 1 {name=p250 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1230 280 0 1 {name=p251 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1230 450 0 1 {name=p252 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1230 420 0 1 {name=p253 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1260 350 0 1 {name=p254 sig_type=std_logic lab=P2}
C {devices/lab_wire.sym} 1260 520 0 1 {name=p255 sig_type=std_logic lab=P4}
C {devices/lab_wire.sym} 1230 590 0 1 {name=p256 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 820 790 0 0 {name=p257 sig_type=std_logic lab=P5}
C {devices/lab_wire.sym} 930 860 0 1 {name=p260 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 930 720 0 1 {name=p262 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1040 740 0 1 {name=p263 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1040 840 0 1 {name=p264 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1230 720 0 1 {name=p265 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1230 860 0 1 {name=p267 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1260 790 0 1 {name=p268 sig_type=std_logic lab=P6}
C {ASWSL.sym} 890 790 0 0 {name=x59}
C {ASWS.sym} 1190 790 0 0 {name=x61}
C {kawamoto_inverter.sym} 1020 790 0 0 {name=x58}
C {devices/lab_wire.sym} 780 900 0 0 {name=p258 sig_type=std_logic lab=PJEND}
C {devices/lab_wire.sym} 820 1060 0 0 {name=p259 sig_type=std_logic lab=P7}
C {devices/lab_wire.sym} 930 1130 0 1 {name=p261 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 930 990 0 1 {name=p266 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1030 1020 0 1 {name=p269 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1030 1100 0 1 {name=p270 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1230 990 0 1 {name=p271 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1230 1130 0 1 {name=p272 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1260 1060 0 1 {name=p273 sig_type=std_logic lab=P9}
C {ASWSL.sym} 890 1060 0 0 {name=x60}
C {ASWS.sym} 1190 1060 0 0 {name=x62}
C {devices/lab_wire.sym} 780 1170 0 0 {name=p274 sig_type=std_logic lab=PJENC}
C {kamiyama_inverter.sym} 1030 1060 0 0 {name=x63}
C {ASWSL.sym} 1570 -670 0 0 {name=x54}
C {ASWSL.sym} 1570 -500 0 0 {name=x55}
C {ASWSL.sym} 1570 -330 0 0 {name=x56}
C {ASW.sym} 2180 -670 0 0 {name=x57}
C {ASW.sym} 2180 -500 0 0 {name=x64}
C {ASW.sym} 2180 -330 0 0 {name=x65}
C {ASW.sym} 2380 -670 0 0 {name=x66}
C {ASW.sym} 2380 -500 0 0 {name=x67}
C {ASW.sym} 2380 -330 0 0 {name=x68}
C {kamiyama_Driver.sym} 1880 -500 0 0 {name=x69}
C {devices/lab_wire.sym} 1610 -600 0 1 {name=p126 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1610 -430 0 1 {name=p133 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1610 -260 0 1 {name=p140 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1610 -740 0 1 {name=p143 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1610 -570 0 1 {name=p144 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1610 -400 0 1 {name=p145 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2220 -260 0 1 {name=p146 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2220 -430 0 1 {name=p149 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2220 -600 0 1 {name=p150 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2420 -600 0 1 {name=p151 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2420 -430 0 1 {name=p152 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2420 -260 0 1 {name=p153 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2220 -740 0 1 {name=p155 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2220 -570 0 1 {name=p156 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2220 -400 0 1 {name=p275 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2420 -400 0 1 {name=p276 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2420 -570 0 1 {name=p277 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2420 -740 0 1 {name=p278 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1500 -330 0 0 {name=p279 sig_type=std_logic lab=P1}
C {devices/lab_wire.sym} 1500 -670 0 0 {name=p280 sig_type=std_logic lab=P2}
C {devices/lab_wire.sym} 1500 -500 0 0 {name=p281 sig_type=std_logic lab=P3}
C {devices/lab_wire.sym} 2250 -670 0 1 {name=p282 sig_type=std_logic lab=P4}
C {devices/lab_wire.sym} 2250 -500 0 1 {name=p283 sig_type=std_logic lab=P6}
C {devices/lab_wire.sym} 2250 -330 0 1 {name=p284 sig_type=std_logic lab=P9}
C {devices/lab_wire.sym} 2450 -670 0 1 {name=p285 sig_type=std_logic lab=P7}
C {devices/lab_wire.sym} 2450 -500 0 1 {name=p286 sig_type=std_logic lab=P10}
C {devices/lab_wire.sym} 2450 -330 0 1 {name=p287 sig_type=std_logic lab=P5}
C {devices/lab_wire.sym} 2030 -510 0 1 {name=p288 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2030 -490 0 1 {name=p289 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1450 -220 0 0 {name=p290 sig_type=std_logic lab=PJEN7}
C {ASWSL.sym} 1570 20 0 0 {name=x53}
C {ASWSL.sym} 1570 190 0 0 {name=x70}
C {shishido_opamp_v12.sym} 1830 100 0 0 {name=x71}
C {ASW.sym} 2100 100 0 0 {name=x72}
C {devices/lab_wire.sym} 1610 90 0 1 {name=p291 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1610 260 0 1 {name=p292 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1830 150 0 1 {name=p293 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 2140 170 0 1 {name=p294 sig_type=std_logic lab=VSS}
C {devices/lab_wire.sym} 1610 -50 0 1 {name=p295 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1610 120 0 1 {name=p296 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1830 50 0 1 {name=p297 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 2140 30 0 1 {name=p298 sig_type=std_logic lab=VDD}
C {devices/lab_wire.sym} 1500 20 0 0 {name=p299 sig_type=std_logic lab=P1}
C {devices/lab_wire.sym} 1500 190 0 0 {name=p300 sig_type=std_logic lab=P2}
C {devices/lab_wire.sym} 2170 100 0 1 {name=p301 sig_type=std_logic lab=P3}
C {devices/lab_wire.sym} 1460 300 0 0 {name=p302 sig_type=std_logic lab=PJEN5}
