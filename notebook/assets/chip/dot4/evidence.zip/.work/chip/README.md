# tr_1um_dot4

Centered 2500 × 2500 µm die in the unmodified pinned PDK `OSS_FRAME`.
The 16 stock pads include 14 `OSS_ESD_5V_ANA`, one ESD VDD and one ESD VSS.

Core VDD = +5 V; VMID = 0 V; **ESD VSS = core VSS = substrate = −5 V**.
**ESD VDD is a separate +5 V terminal: apply it before or together with core VDD.**
Bond or probe all three core VDD pads; they join inside the die.
ESD VDD and core VDD are electrically separate inside the chip.

| Pad | Frame pin | Net | Pad cell | X (µm) | Y (µm) |
|---|---|---|---|---:|---:|
| P01 | P1 | VDD | OSS_ESD_5V_ANA | -200 | 1040 |
| P02 | P2 | VDD | OSS_ESD_5V_ANA | -600 | 1040 |
| P03 | P3 | x1 | OSS_ESD_5V_ANA | -1040 | 600 |
| P04 | P4 | x0 | OSS_ESD_5V_ANA | -1040 | 200 |
| P05 | P5 | w3 | OSS_ESD_5V_ANA | -1040 | -200 |
| P06 | P6 | w2 | OSS_ESD_5V_ANA | -1040 | -600 |
| P07 | P7 | w0 | OSS_ESD_5V_ANA | -600 | -1040 |
| P08 | VSS | VSS | OSS_ESD_5V_VSS | -200 | -1040 |
| P09 | P9 | x3 | OSS_ESD_5V_ANA | 200 | -1040 |
| P10 | P10 | w1 | OSS_ESD_5V_ANA | 600 | -1040 |
| P11 | P11 | y[1] | OSS_ESD_5V_ANA | 1040 | -600 |
| P12 | P12 | y[0] | OSS_ESD_5V_ANA | 1040 | -200 |
| P13 | P13 | VMID | OSS_ESD_5V_ANA | 1040 | 200 |
| P14 | P14 | x2 | OSS_ESD_5V_ANA | 1040 | 600 |
| P15 | P15 | VDD | OSS_ESD_5V_ANA | 600 | 1040 |
| P16 | VDD | ESD_VDD | OSS_ESD_5V_VDD | 200 | 1040 |

Remaining organizer steps:

- Allocate a complete 2500 × 2500 µm slot for this top.
- Agree the final bond diagram, including every supply bond and the VSS substrate.
- Complete the submission metadata/reference package and run the organizer's final CI.

Drawing DRC, strict device/port LVS including the ESD devices, MDP, mask DRC,
the copied organizer precheck and the DC width/cut reserve are recorded separately.
No post-MDP LVS stage is defined by the inspected organizer workflow.
Current limits use conservative engineering width scaling; this is not lifetime EM qualification.
